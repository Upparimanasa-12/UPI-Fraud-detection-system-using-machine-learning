from flask import Flask, render_template, request, redirect, url_for, session
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# --- Store registered users ---
users = {'admin': 'admin'}

# --- Load model and scaler ---
fraud_model = joblib.load('fraud_model.pkl')
scaler = joblib.load('scaler.pkl')

# --- Load dataset to recreate LabelEncoders ---
df = pd.read_csv("C:/Users/manas/OneDrive/Desktop/fraud_detection_webapp/dataset.csv")
categorical_cols = ['Transaction_Type', 'Device_Used', 'Location', 'Payment_Method']
label_encoders = {}

for col in categorical_cols:
    le = LabelEncoder()
    df[col] = df[col].astype(str)
    le.fit(df[col])
    label_encoders[col] = le

def safe_label_encode(le, value):
    if value in le.classes_:
        return le.transform([value])[0]
    else:
        le_classes = list(le.classes_)
        le_classes.append(value)
        le.classes_ = np.array(le_classes)
        return le.transform([value])[0]

# --- Routes ---
@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    if username in users and users[username] == password:
        session['user'] = username
        return redirect(url_for('predict_form'))
    else:
        return render_template('login.html', error='Invalid username or password')

@app.route('/register', methods=['POST'])
def register():
    new_username = request.form['new_username']
    new_password = request.form['new_password']
    confirm_password = request.form['confirm_password']

    if new_password != confirm_password:
        return render_template('login.html', error='Passwords do not match!')

    if new_username in users:
        return render_template('login.html', error='Username already exists!')

    users[new_username] = new_password
    session['user'] = new_username
    return redirect(url_for('predict_form'))

@app.route('/predict', methods=['GET', 'POST'])
def predict_form():
    if request.method == 'POST':
        form_data = {
            'Transaction_Amount': float(request.form['Transaction_Amount']),
            'Transaction_Type': request.form['Transaction_Type'],
            'Time_of_Transaction': int(request.form['Time_of_Transaction']),
            'Device_Used': request.form['Device_Used'],
            'Location': request.form['Location'],
            'Previous_Fraudulent_Transactions': int(request.form['Previous_Fraudulent_Transactions']),
            'Account_Age': int(request.form['Account_Age']),
            'Number_of_Transactions_Last_24H': int(request.form['Number_of_Transactions_Last_24H']),
            'Payment_Method': request.form['Payment_Method']
        }

        # Encode categorical features
        for col in categorical_cols:
            le = label_encoders[col]
            form_data[col] = safe_label_encode(le, form_data[col])

        # Check if Previous_Fraudulent_Transactions is 0 or greater than 0
        if form_data['Previous_Fraudulent_Transactions'] == 0:
            result = 'Legitimate Transaction'
        else:
            result = 'Fraudulent Transaction'

        return render_template('result.html', result=result)

    return render_template('predict.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True, port=5001)
