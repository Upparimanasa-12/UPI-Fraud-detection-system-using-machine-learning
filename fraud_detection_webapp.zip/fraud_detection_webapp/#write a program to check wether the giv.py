#write a program to check wether the given number or not
sum=0
def perfect_num(n):
    for i in range(1,n):
        if n%i==0:
            sum+=i
    if n==sum:
        print(perfect_num(6))