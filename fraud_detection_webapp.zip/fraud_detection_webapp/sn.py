#write a program to check wether the given number or not
'''sum=0
def perfect_num(n):
    for i in range(1,n):
        if n%i==0:
            sum+=i
    if n==sum:
        print(perfect_num(6))'''
n=int(input())
sum=0
for i in range(1,n):
    if n%i==0:
        sum+=i
if n==sum:
    print("perfect")
else:
    print("not perfect")
